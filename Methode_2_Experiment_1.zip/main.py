from baufuzz.logs import FuzzingLog
from baufuzz.compilers import Compiler
from baufuzz.fuzzers import GrammarFuzzer
from baufuzz.runners import ProgramRunnerFileInput
from baufuzz.analyzers import crashes_over_time
from baufuzz.grammars import SIMPLE_C_GRAMMAR

# Initialization
program = Compiler().compile("./kilo_direct_quit.c")
fuzzer = GrammarFuzzer(SIMPLE_C_GRAMMAR)
runner = ProgramRunnerFileInput(program,
                                "/tmp/test.c",
                                ["/tmp/test.c"],
                                coverage_type=None)
log = FuzzingLog(fuzzer, runner)

# Run
fuzzer.runs(runner=runner, duration_min=30)
log.save("./out")

# Analysis
crashes_over_time(log)
