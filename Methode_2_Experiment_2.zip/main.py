from baufuzz.logs import FuzzingLog
from baufuzz.compilers import Compiler
from baufuzz.seeders import GrammarSeeder
from baufuzz.fuzzers import MutationFuzzer
from baufuzz.runners import ProgramRunnerFileInput
from baufuzz.grammars import SIMPLE_C_GRAMMAR
from baufuzz.coverages import CoverageType
from baufuzz.analyzers import branch_coverage_over_time, crashes_over_time, line_coverage_over_time

# Initialization
seeds = GrammarSeeder(SIMPLE_C_GRAMMAR, n=100).seeds()
program = Compiler().compile("./kilo_direct_quit.c")
fuzzer = MutationFuzzer(seeds)
runner = ProgramRunnerFileInput(program,
                                "/tmp/test.c",
                                ["/tmp/test.c"],
                                coverage_type=CoverageType.BRANCH)
log = FuzzingLog(fuzzer, runner)

# Run
fuzzer.runs(runner=runner, duration_min=30)
log.save("./out")

# Analysis
line_coverage_over_time(log)
branch_coverage_over_time(log)
crashes_over_time(log)
