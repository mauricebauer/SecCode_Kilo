from baufuzz.logs import FuzzingLog
from baufuzz.seeders import FileSeeder
from baufuzz.compilers import Compiler
from baufuzz.coverages import CoverageType
from baufuzz.schedules import AFLFastSchedule
from baufuzz.fuzzers import CountingGreyboxFuzzer
from baufuzz.runners import ProgramRunnerFileInput
from baufuzz.analyzers import crashes_over_time, line_coverage_over_time

# Initialization
seeds = FileSeeder("./in").seeds()
program = Compiler().compile("./kilo_direct_quit.c")
schedule = AFLFastSchedule(10)
fuzzer = CountingGreyboxFuzzer(seeds, schedule=schedule)
runner = ProgramRunnerFileInput(program,
                                "/tmp/test.c",
                                ["/tmp/test.c"],
                                coverage_type=CoverageType.LINE)
log = FuzzingLog(fuzzer, runner)

# Run
fuzzer.runs(runner=runner, duration_min=30)
log.save("./out")

# Analysis
line_coverage_over_time(log)
crashes_over_time(log)
