from baufuzz.logs import FuzzingLog
from baufuzz.seeders import FileSeeder
from baufuzz.compilers import Compiler
from baufuzz.coverages import CoverageType
from baufuzz.schedules import DirectedSchedule
from baufuzz.fuzzers import CountingGreyboxFuzzer
from baufuzz.runners import ProgramRunnerFileInput
from baufuzz.analyzers import crashes_over_time, get_call_graph, line_coverage_over_time

# Initialization
seeds = FileSeeder("./in").seeds()
graph = get_call_graph("./kilo_direct_quit.c")
program = Compiler().compile("./kilo_direct_quit.c")
schedule = DirectedSchedule(10, graph, "editorUpdateSyntax", "./kilo_direct_quit.c")
fuzzer = CountingGreyboxFuzzer(seeds, schedule=schedule)
runner = ProgramRunnerFileInput(program,
                                "/tmp/test.c",
                                ["/tmp/test.c"],
                                coverage_type=CoverageType.LINE)
log = FuzzingLog(fuzzer, runner)

# Run
fuzzer.runs(runner=runner, duration_min=30)
log.save("./out")

# Analysis
line_coverage_over_time(log)
crashes_over_time(log)
