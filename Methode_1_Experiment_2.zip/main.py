from baufuzz.logs import FuzzingLog
from baufuzz.seeders import FileSeeder
from baufuzz.coverages import CoverageType
from baufuzz.fuzzers import MutationCoverageFuzzer
from baufuzz.runners import ProgramRunnerFileInput
from baufuzz.compilers import Compiler
from baufuzz.analyzers import crashes_over_time, line_coverage_over_time

# Initialization
seeds = FileSeeder("./in").seeds()
program = Compiler().compile("./kilo_direct_quit.c")
fuzzer = MutationCoverageFuzzer(seeds=seeds)
runner = ProgramRunnerFileInput(program,
                                "/tmp/test.c",
                                ["/tmp/test.c"],
                                coverage_type=CoverageType.LINE)
log = FuzzingLog(fuzzer, runner)

# Run
fuzzer.runs(runner=runner, duration_min=30)
log.save("./out")

# Analysis
line_coverage_over_time(log)
crashes_over_time(log)
